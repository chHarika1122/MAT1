package com.cg.lab5;
import java.util.Scanner;
 class EmployeeException extends RuntimeException{
	EmployeeException()
	{
		System.out.println("Salary to be greater than 3000");
	}
}
public class Excercise6 {
	public static void main(String[] args) throws Exception {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the salary");
		int sal=s.nextInt();
		s.close();
		try {
			if(sal<3000)
				throw new EmployeeException();
			else
				System.out.println("Salary"+sal);
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
