package com.cg.lab5;
import java.util.Scanner;
public class Excercise4 {
public static void main(String[] args) throws Exception {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter first name");
	String fname=s.nextLine();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter last name ");
	String lname=sc.nextLine();
	s.close();
	sc.close();
	try {
		if(fname.length()==0 && lname.length()==0)
			System.out.println("Inavlid data");
		else
			System.out.println("Name is "+fname +lname);
			
	}catch(Exception e)
	{
		System.out.println(e);
	}
}
}