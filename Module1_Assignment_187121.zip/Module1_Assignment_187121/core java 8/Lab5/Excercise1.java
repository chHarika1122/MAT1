package com.cg.lab5;
import java.util.Scanner;
public class Excercise1 {
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("enter the choice");
		String choice=s.nextLine();
		switch(choice)
		{
		case "red":System.out.println("stop");
		           break;
		case "green":System.out.println("go");
		             break;
		case "yellow":System.out.println("ready");
		              break;
		default: System.out.println("no choice");              
		}
	}

}

