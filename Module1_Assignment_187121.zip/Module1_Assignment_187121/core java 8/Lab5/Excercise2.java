package com.cg.lab5;

public class Excercise2 {
static int n1=1,n2=1,temp=0;
static void fibbo(int count)
{
	if(count>0)
	{
		temp=n1+n2;
		n1=n2;
		n2=temp;
		System.out.println(temp);
		fibbo(count-1);
	}
}
public static void main(String[] args)
{
	int count=5;
	//Scanner s=new Scanner(System.in);
	System.out.println("enter the number");
	System.out.println("with recursion");
	System.out.println(n1+" "+n2);
	fibbo(count-2);
	System.out.println("without recursion");
	int a=1,b=1,i,c;
	System.out.println(a+" "+b);
	for(i=2;i<count;++i) 
	{
	c=a+b;
	System.out.println(" "+c);
	a=b;
	b=c;
	}
		
}
}
