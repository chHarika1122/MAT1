package com.cg.lab5;
import java.util.Scanner; 
public class Excercise5 {
public static void main(String[] args) throws Exception {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter age");
	int age=s.nextInt();
	s.close();
	try {
		if(age<15)
			System.out.println("Age is less than 15");
		else
			System.out.println("Age is:"+age);
	}catch(Exception e)
	{
		System.out.println(e);
	}
}
}
