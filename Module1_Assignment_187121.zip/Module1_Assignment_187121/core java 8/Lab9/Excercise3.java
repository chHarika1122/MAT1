package com.cg.lab9;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Excercise3 {
HashMap countSquares(int[] ch) {
	HashMap<Integer,Integer>hm1=new HashMap<Integer,Integer>();
	int l=ch.length;
	int sq[]=new int[l];
	for(int i=0;i<l;i++) {
		sq[i]=ch[i]*ch[i];
		hm1.put(ch[i], sq[i]);
		
	}
	return hm1;
}

public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter length");
	int i;
	int n=s.nextInt();
	int ch[]=new int[n];
	System.out.println("Enter number");
	for( i=0;i<n;i++) {
		ch[i]=s.nextInt();
	}
	Excercise3 ee=new Excercise3();
	HashMap<Integer,Integer>hm=new HashMap<Integer,Integer>();
	hm=ee.countSquares(ch);
	for(Map.Entry mp:hm.entrySet()) {
		int key=(int)mp.getKey();
		int count=(int)mp.getValue();
		System.out.println(key+":"+count);
	}
	s.close();
}
}
