package com.cg.lab9;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class Excercise1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value");
		int val=sc.nextInt();
		String values;
		int counter=1;
		HashMap hm=new HashMap();
		while(counter<=val) {
			System.out.println("Enter key: " +counter);
			values =sc.next();
			hm.put(counter, values);
			counter++;
			}
		Excercise1 ex=new Excercise1();
		List list=ex.getValues(hm);
		System.out.println(list);
		
	}

	private List getValues(HashMap hm) {
		// TODO Auto-generated method stub
		List list=new ArrayList();
		int length=hm.size();
		for(int i=1;i<=length;i++) {
			list.add(hm.get(i));
		}
		list.sort(null);
		return list;
	}

}
