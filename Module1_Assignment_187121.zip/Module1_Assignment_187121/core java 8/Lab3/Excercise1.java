package com.cg.lab3;
import java.util.Scanner;
//class with method
public class Excercise1 {
	public static int getSecondSmallest(int a[],int n)
	{
		//declaring variables
	int t;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n-i-1;j++)
		{
			if(a[j]>a[j+1])
			{
				//comparing elements
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			}
		}
	}
	System.out.println("sorted array");
	//displaying sorted array
	for(int i=0;i<n;i++)
	{
		System.out.println(a[i]+" ");
	}
	//display second smallest number
	System.out.println("Second smallest element "+a[1]);
	return a[1];
	}
	//main function with method
public static void main(String[] args)
{
	Scanner s=new Scanner(System.in);
	System.out.println("enter the number");
	int n=s.nextInt();
	//creating array
	int[] arr= new int[n];
System.out.println("enter the elements");
//elements of array
for(int k=0;k<n;k++)
	{
		arr[k]=s.nextInt();
	}
	
	getSecondSmallest(arr,n);
}
}
