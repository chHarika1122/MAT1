package com.cg.lab3;
import java.util.Scanner;
public class Excercise2 {
	public static String[] StringArray(String[] array, int n)
	{
		String b;
		int c;
		for(int k=0;k<n;k++)
		{
			for(int j=0;j<n-k-1;j++)
			{
			if(array[k].compareTo(array[j])>0)
			{
				b=array[j];
				array[j]=array[j+1];
				array[j+1]=b;
			}
			}
		}
		System.out.println("sorted array");
		for(int k=0;k<n;k++)
		{
			System.out.println(array[k]+" ");
		}
		if(n%2==0)
		{
			
			c=n/2;
			
			//return array[c];
		}
		else
		{
			c=(n/2)+1;
			
			//return array[d];
		}
		for(int k=0;k<c;k++)
		{
			System.out.println(array[k].toUpperCase());
		}
		for(int k=c;k<n;k++)
		{
			System.out.println(array[k].toLowerCase());
		}
		for(int k=0;k<n;k++)
		{
			System.out.println(array[k]);
		}
		return array;
	}
public static void main(String[] args)
{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the number");
	int n=s.nextInt();
	String a=s.toString();
	String[] array= new String[n];
	for(int i=0;i<array.length;i++)
	{
		array[i]=s.toString();
	}
	StringArray(array,n);
}
}
