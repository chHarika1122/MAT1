package com.cg.lab8;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Excercise7 {
	public boolean validate(String s)
	{
		Pattern p=Pattern.compile("[a-zA-Z]{8,}_job");
		Matcher m=p.matcher(s);
		if(m.matches()) {
			System.out.println("validate passed");
			return true;
		}
		else {
			System.out.println("validate failure");
			return false;
		}
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String str=sc.next();
		Excercise7 ex=new Excercise7();
		ex.validate(str);
	}

}
