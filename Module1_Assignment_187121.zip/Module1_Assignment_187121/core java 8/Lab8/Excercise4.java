package com.cg.lab8;

import java.io.File;

public class Excercise4 {
public static void main(String[] args) {
	File f=new File("c:\\Users\\chharika\\Documents\\target.txt");
	if(f.exists()) {
		System.out.println("file "+f.getName()+" exists");
		if(f.canRead())
		{
			System.out.println("file is "+f.getName()+" is readable");
			}
		else
		{
			System.out.println("file is "+f.getName()+" readble");
		}
		if(f.canWrite()) {
			System.out.println("file is "+f.getName()+" is writable");
		}
		else
		{
			System.out.println("file is not "+f.getName()+" writable");
		}
		
	}
	else
	{
		System.out.println("file does not exists "+f.getName());
	}
	System.out.println("file type is "+f.getName().substring(f.getName().indexOf(" .")+1));
	System.out.println("length of the file is "+f.length());
	
}
}
