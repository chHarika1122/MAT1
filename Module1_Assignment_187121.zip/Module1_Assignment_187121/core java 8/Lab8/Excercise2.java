package com.cg.lab8;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class Excercise2 {
public static void main(String[] args) throws IOException {
	int c=0;
	String s=" Hi \n Hello \n World \n";
	char buffer[]=new char[s.length()];
	s.getChars(0, s.length(), buffer, 0);
	FileWriter fr=new FileWriter("file.txt");
	fr.write(buffer);
	fr.close();
	FileReader fR=new FileReader("file.txt");
	BufferedReader br=new BufferedReader(fR);
	String t;
	while((t=br.readLine())!=null)
	{
		c++;
		System.out.println(c+"  "+t);
	}
	fR.close();
}
}
