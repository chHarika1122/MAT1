package com.cg.lab8;

import java.time.LocalDate;
import java.time.Period;

public class Excercise6 {
public static void main(String[] args) {
	LocalDate pastdate=LocalDate.of(2018, 05, 02);
	LocalDate currdate=LocalDate.now();
	Period diff=Period.between(pastdate, currdate);
	System.out.println("Days: "+diff.getDays());
	System.out.println("Months: "+diff.getMonths());
	System.out.println("Years: "+diff.getYears());
}
}
