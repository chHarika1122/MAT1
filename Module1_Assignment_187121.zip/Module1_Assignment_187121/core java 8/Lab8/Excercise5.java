package com.cg.lab8;
import java.util.Scanner;
public class Excercise5{
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter string");
	String s=sc.nextLine().toUpperCase();
		int i=0,f=0;
		char ch[]=s.toCharArray();
		int len=ch.length;
		for(i=0;i<len-1;i++) {
			char a=ch[i];
			char b=ch[i+1];
			if(a>=b) {
				f=1;
				break;
			}
		}
		if(f==0)
			System.out.println("positive string");
		else
			System.out.println("not positive string");
	}
}
