package com.cg.lab8;
import java.util.Scanner;
public class Excercise3 {
public static void main(String[] args)  {
	Scanner s= new Scanner(System.in);
	System.out.println("Enter the string");
	String str=s.nextLine();
	int line=1,word=0,chars=0;
	int i;
	str=str+' ';
	char ch[]=str.toCharArray();
	int len=ch.length;
	for(i=0;i<len-1;i++) {
		char chr=ch[i];
		char b=ch[i+1];
		if((chr>=65&&chr<=90)||(chr>=97&&chr<=120)) 
		chars++;
		if(b==' '&&chr!=' ')
			word++;
		if(chr=='\n')
			line++;
		
	}
	System.out.println("characters: "+chars);
	System.out.println("words: "+word);
	System.out.println("lines: "+line);

}

}
