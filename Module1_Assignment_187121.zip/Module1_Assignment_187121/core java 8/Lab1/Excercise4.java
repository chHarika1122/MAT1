package com.cg.lab1;
import java.util.Scanner;
//using method in class
public class Excercise4 {
	public static boolean checkNumber(int n)
	{
		//checking condition
		if(n%2==0)
		{
		for(int i=1;i<=n;i++)
		{
			//condition to check power of 2
			if(Math.pow(2, i)==n)
			{
				System.out.println("power of 2");	
				return true;
			}
			
		}System.out.println("not a power of 2");
				return false;
			
			
			
	}
		else
		{
			System.out.println("not power of 2");
			return false;
		}
		
	}
	// main function with method
public static void main(String[] args)
{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the number");
	int n=s.nextInt();
	checkNumber(n);
}
}
