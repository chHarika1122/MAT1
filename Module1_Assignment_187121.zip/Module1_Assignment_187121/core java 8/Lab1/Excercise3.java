package com.cg.lab1;
import java.util.Scanner;
//class with method
public class Excercise3 {
	public static boolean checkNumber(int number)
	{
		int n;
		//initialization
		boolean flag=true;
		n=number%10;
		number=number/10;
//Calculating increasing number
		while(n>0)
		{
			if(n<number%10)
			{
				flag=false;
				System.out.println("not increasing number");
				return flag;
			
		}
			n=number%10;
			number=number/10;
	}
		System.out.println("increasing number");
			return flag;
	}
	//main function
public static void main(String[] args)
{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the number");
	int number=s.nextInt();
	checkNumber(number);
	
}
}
