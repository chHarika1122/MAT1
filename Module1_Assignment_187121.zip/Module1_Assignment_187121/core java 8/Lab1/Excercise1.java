package com.cg.lab1;
import java.util.Scanner;
public class Excercise1 {
	//Method of a class 
	public static int CalculateSum(int n)
	{
		//initialization
		int sum=0;
		if(n>0)
		{
			//start of loop
		for(int i=1;i<=n;i++)
		{
			if(i%3==0 || i%5==0)
			{
				//calculate the sum
				sum=sum+i;
			}
		}
		System.out.println("Result is: " +sum);
		return sum;
	}
		else
		{
			System.out.println("Invalid input");
			return sum;
		}
	}
	//creating a main function
public static void main(String[] args)
{
	//read the input
	Scanner s = new Scanner(System.in);
	System.out.println("enter the number");
	int n=s.nextInt();
	CalculateSum(n);
	
}
}
