package com.cg.lab1;
import java.util.Scanner;
//class with method
public class Excercise2 {
	public static int CalculateDifference(int n)
	{
		//initializing variables
		int sum=0,Difference=0,c=0,b=0;
		int a;
		if(n>0)
		{
		for(int i=1;i<=n;i++)
		{
			//calculating sum of squares of numbers
			a=i*i;
			sum=sum+a;
		}
		for(int j=1;j<=n;j++)
		{
			//calculating square of sum of the numbers
			b=b+j;
			c=b*b;
		}
		//calculating Difference
		Difference=sum-c;
		System.out.println("Difference is "+Difference);
		return Difference;
		}
		else
		{
			System.out.println("Inavlid data");
			return Difference;
		}
	}
//main function
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number");
		int n=s.nextInt();
		CalculateDifference(n);
	}
}
