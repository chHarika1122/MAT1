package com.cg.lab13;

import java.util.Scanner;
import java.util.function.UnaryOperator;

public class Excercise2 {
public static void main(String[] args) {
	
UnaryOperator<String> uo=(str)->{	
	String res=" ";
	for(int i=0;i<str.length();i++) {
		res=res+str.charAt(i);
		if(i==str.length()-1)
break;
		res=res+" ";
	}
	return res;
};
Scanner sc=new Scanner(System.in);
System.out.println("Enter the string");
String str=sc.nextLine();
System.out.println(uo.apply(str));
}
}
