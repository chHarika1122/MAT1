package com.cg.lab13;

import java.util.Scanner;
import java.util.function.BiFunction;

public class Excercise1 {
	public static void main(String[] args) {
		BiFunction<Integer,Integer,Integer> bf=(x,y)->{
			int result= (int) Math.pow(x, y);
			return result;
		};
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the base");
		int x=sc.nextInt();
		System.out.println("Enter the poewr");
		int y=sc.nextInt();
		System.out.println(bf.apply(x, y));
		
	}

}
