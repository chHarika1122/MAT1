package com.cg.lab13;

import java.util.Scanner;
import java.util.function.BiPredicate;

public class Excercise3 {
public static void main(String[] args) {
	BiPredicate<String,String>bp=(uname,passw)->{
		if(uname.equals("abcde")&&passw.equals("1234")) {
			return true;
		}
		else
		{
			return false;
		}
	};
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter username");
	String username=sc.nextLine();
	System.out.println("Enter password");
	String password=sc.nextLine();
	System.out.println(bp.test(username, password));
}
}
