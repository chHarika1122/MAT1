package com.cg.lab4;
import java.util.Scanner;
//class with method
public class Excercise1 {
	public static int sumOfCubes(int n)
	{
		//declaring and initializing variables
		int a,sum=0;
		while(n>0)
		{
			//calculating sum of cubes 
			a=n%10;
			sum=sum+(a*a*a);
			n=n/10;
		}
		System.out.println("sum of cubes "+sum);
		return sum;
	}
	//method with main function to find sum of cubes
public static void main(String[] args)
{
	Scanner s= new Scanner(System.in);
	System.out.println("enter the number");
	int n=s.nextInt();
	sumOfCubes(n);
}
}
