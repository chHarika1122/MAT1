package ex1.part2.com.cg.author.service;

import java.util.List;

import ex1.part2.com.cg.author.bean.AuthorBean;
import ex1.part2.com.cg.author.dao.AuthorDao;

public class AuthorService {

	AuthorDao daoObj = new AuthorDao();
	
	public int insertAuthor(AuthorBean beanObj) {
		int rows = daoObj.addAuthor(beanObj);
		return rows;
	}
	
	public int updateAuthor(Integer authorId,Long phoneNo) {
		int rows = daoObj.updateAuthor(authorId,phoneNo);
		return rows;
	}
	
	public int deleteAuthor(Integer authorId) {
		int rows = daoObj.deleteAuthor(authorId);
		return rows;
	}
	
	public List<AuthorBean> viewAuthor(Integer authorId) {
		List<AuthorBean> list = daoObj.viewAuthor(authorId);
		return list;
	}
}
