package ex1.part2.com.cg.author.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ex1.part2.com.cg.author.bean.AuthorBean;

public class AuthorDao {

	Connection conn = null;
	PreparedStatement ps = null;
	int rows = 0;
	ResultSet rs = null; 
	GetConnection gc = new GetConnection();
	
	public int addAuthor(AuthorBean beanObj) {
	try {
		conn = gc.getConn();
		String sql = "insert into author values(?,?,?,?,?)";
		ps = conn.prepareStatement(sql);
		ps.setInt(1,beanObj.getAuthorId());
		ps.setString(2, beanObj.getFirstName());
		ps.setString(3, beanObj.getMiddleName());
		ps.setString(4, beanObj.getLastName());
		ps.setLong(5, beanObj.getPhoneNo());
		rows = ps.executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally {
		if(conn!=null) {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				
			}
			
		}
	}
		return rows;
	}
	
	public int updateAuthor(Integer authorId,Long phoneNo) {
		try {
			conn = gc.getConn();
			String sql = "update author set phoneNo=? where authorId=?";
			ps = conn.prepareStatement(sql);
			ps.setLong(1,phoneNo);
			ps.setInt(2,authorId);
			rows = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(conn!=null) {
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					
				}
				
			}
		}
			return rows;
		}
	
	public int deleteAuthor(Integer authorId) {
		try {
			conn = gc.getConn();
			String sql = "delete from author where authorId=?";
			ps = conn.prepareStatement(sql);
			ps.setLong(1,authorId);
			rows = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(conn!=null) {
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					
				}
				
			}
		}
			return rows;
		}
	
	@SuppressWarnings("rawtypes")
	public List<AuthorBean> viewAuthor(Integer authorId) {
		@SuppressWarnings("unchecked")
		List<AuthorBean> authorList = new ArrayList();
		try {
			conn = gc.getConn();
			String sql = "select * from author where authorId=?";
			ps = conn.prepareStatement(sql);
			ps.setLong(1,authorId);
			rs = ps.executeQuery();
			while(rs.next()) {
				AuthorBean beanObj = new AuthorBean();
				beanObj.setAuthorId(rs.getInt("authorId"));
				beanObj.setFirstName(rs.getString("firstName"));
				beanObj.setMiddleName(rs.getString("middleName"));
				beanObj.setLastName(rs.getString("lastName"));
				beanObj.setPhoneNo(rs.getLong("phoneNo"));
				authorList.add(beanObj);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(conn!=null) {
				try {
					rs.close();
					ps.close();
					conn.close();
				} catch (SQLException e) {
					
				}
				
			}
		}
			return authorList;
		}
	
}
