package lab13.com.erd.service;

import java.util.List;
import lab13.com.erd.bean.Author;
import lab13.com.erd.bean.Book;
import lab13.com.erd.bean.BookAuthor;
import lab13.com.erd.dao.ERDDao;

public class ERDService {

	ERDDao daoObj = new ERDDao();
	//Book book = new Book();
	//Author author = new Author();
	BookAuthor bookAuthor = new BookAuthor();
	
	
	// method to call dao object to add a row in  table
	public int insertDetails(Book book, Author author) {
		int book_id = (int)((book.getPrice()*7)-19);
		int author_id = (int)((book.getPrice()*7)-19);
		Integer isbn = (int)book_id; 
		Integer id = (int)author_id;
		book.setIsbn(isbn);
		author.setId(id);
		bookAuthor.setIsbn(isbn);
		bookAuthor.setId(id);
		return daoObj.insertDetails(book, author);
	}
	
	// method to call dao object to retrieve the data
	public List<String> getValues(String name) {
		return daoObj.getValues(name);
	}
	
	// method to call dao object to update the details
	public int updateElement(Integer isbn, Double price) {
		return daoObj.updateElement(isbn, price);
	}
}
