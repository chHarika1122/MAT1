package lab13.com.erd.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import lab11.com.collection.util.DatabaseConnection;
import lab13.com.erd.bean.Author;
import lab13.com.erd.bean.Book;

public class ERDDao {

	Connection con=null;
	PreparedStatement ps1 = null;
	PreparedStatement ps2 = null;
	PreparedStatement ps3 = null;
	ResultSet rs = null;
	static int row = 0;
	
	// method to add a row in the table
	public int insertDetails(Book book, Author author) {

			try {
				con = DatabaseConnection.getConnection();
				String sql1 = "insert into book values(?,?,?)";
				String sql2 = "insert into author values(?,?)";
				String sql3 = "insert into bookauthor values(?,?)";
				ps1 = con.prepareStatement(sql1);
				ps1.setInt(1, book.getIsbn());
				ps1.setString(2, book.getTitle());
				ps1.setDouble(3, book.getPrice());
				row = row + ps1.executeUpdate();
				ps2 = con.prepareStatement(sql2);
				ps2.setInt(1, author.getId());
				ps2.setString(2, author.getName());
				row = row + ps2.executeUpdate();
				ps3 = con.prepareStatement(sql3);
				ps3.setInt(1, book.getIsbn());
				ps3.setInt(2, author.getId());
				row = row + ps3.executeUpdate();
			}
			catch(Exception e) {
				System.out.println("Error Occurred while establishing connection");
			}
			finally {
				if(con!=null) {
					try {
						ps1.close();
						ps2.close();
						ps3.close();
						con.close();
					}
					catch(SQLException e) {
						System.out.println("Your Collection is not properly closed.");
					}
				}
			}
			return row;
	}
		
	// method to update a row from the table
	public int updateElement(Integer isbn, Double price) {
			try {
				con = DatabaseConnection.getConnection();
				String sql = "update book set price=? where isbn=?";
				ps1 = con.prepareStatement(sql);
				ps1.setInt(1, isbn);
				ps1.setDouble(2, price);
				row = ps1.executeUpdate();
			}
			catch(Exception e) {
				System.out.println("Error Occurred while establishing connection");
			}
			finally {
				if(con!=null) {
					try {
						ps1.close();
						con.close();
					}
					catch(SQLException e) {
						System.out.println("Your Collection is not properly closed.");
					}
				}
			}
			return row;
		}
		
		
		// method to retrieve the data from the table
		public List<String> getValues(String name) {
			List<String> list = new ArrayList<String>();
			try {
				con = DatabaseConnection.getConnection();
				String sql = "Select title from book b inner join bookauthor ba on b.isbn=ba.isbn inner join author a on ba.id=a.id where name=?";
				ps1.setString(1, name);
				ps1 = con.prepareStatement(sql);
				rs = ps1.executeQuery();
				while(rs.next()) {
					list.add(rs.getString("title"));
				}
			}
			catch(Exception e) {
				System.out.println("Error Occurred while establishing connection");
			}
			finally {
				if(con!=null) {
					try {
						rs.close();
						ps1.close();
						ps2.close();
						ps3.close();
						con.close();
					}
					catch(SQLException e) {
						System.out.println("Your Collection is not properly closed.");
					}
				}
			}
			return list;
		} 
}
