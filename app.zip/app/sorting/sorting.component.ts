import { Component, OnInit } from '@angular/core';
import data from '../data/sort.json';
@Component({
  selector: 'app-sorting',
  templateUrl: './sorting.component.html',
  styleUrls: ['./sorting.component.css']
})
export class SortingComponent implements OnInit {
employees=data;
  constructor() { }

  ngOnInit() {
  }
sort()
{
  this.employees.sort((a,b) => (a.empId>b.empId)?1:-1)
}
sort1()
{
  this.employees.sort((a,b) => (a.empName>b.empName)?1:-1)
}
sort2()
{
  this.employees.sort((a,b) => (a.empSal>b.empSal)?1:-1)
}
sort3()
{
  this.employees.sort((a,b) => (a.empDep>b.empDep)?1:-1)
}
}
